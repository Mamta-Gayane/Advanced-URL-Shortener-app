// Install dependencies
// npm install passport passport-google-oauth20 express-session

const express = require('express');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;

passport.use(new GoogleStrategy({
    clientID: 'YOUR_GOOGLE_CLIENT_ID',
    clientSecret: 'YOUR_GOOGLE_CLIENT_SECRET',
    callbackURL: '/auth/google/callback'
  },
  function(accessToken, refreshToken, profile, done) {
    // Save the user's profile in the database or session
    return done(null, profile);
  }
));

const app = express();

app.use(require('express-session')({ secret: 'secret', resave: true, saveUninitialized: true }));
app.use(passport.initialize());
app.use(passport.session());

app.get('/auth/google', passport.authenticate('google', { scope: ['https://www.googleapis.com/auth/plus.login'] }));

app.get('/auth/google/callback', passport.authenticate('google', { failureRedirect: '/' }),
  (req, res) => {
    res.redirect('/');
  });

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});


const express = require('express');
const mongoose = require('mongoose');
const shortid = require('shortid');
const rateLimit = require('express-rate-limit');

mongoose.connect('mongodb://localhost/urlshortener', { useNewUrlParser: true, useUnifiedTopology: true });

const urlSchema = new mongoose.Schema({
  longUrl: String,
  shortUrl: String,
  customAlias: String,
  topic: String,
  createdAt: { type: Date, default: Date.now }
});

const Url = mongoose.model('Url', urlSchema);

const app = express();
app.use(express.json());

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100
});

app.post('/api/shorten', limiter, async (req, res) => {
  const { longUrl, customAlias, topic } = req.body;
  const shortUrl = customAlias || shortid.generate();
  const newUrl = new Url({ longUrl, shortUrl, customAlias, topic });
  await newUrl.save();
  res.json({ shortUrl, createdAt: newUrl.createdAt });
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});


app.get('/api/shorten/:alias', async (req, res) => {
    const url = await Url.findOne({ shortUrl: req.params.alias });
    if (url) {
      // Log analytics data here
      res.redirect(url.longUrl);
    } else {
      res.status(404).send('URL not found');
    }
  });

  
  app.get('/api/analytics/:alias', async (req, res) => {
    // Retrieve analytics data from the database
    const analytics = {
      totalClicks: 100, // Example data
      uniqueUsers: 50,
      clicksByDate: [],
      osType: [],
      deviceType: []
    };
    res.json(analytics);
  });

  app.get('/api/analytics/topic/:topic', async (req, res) => {
    // Retrieve topic-based analytics data from the database
    const analytics = {
      totalClicks: 500, // Example data
      uniqueUsers: 200,
      clicksByDate: [],
      urls: []
    };
    res.json(analytics);
  });

  app.get('/api/analytics/overall', async (req, res) => {
    // Retrieve overall analytics data from the database
    const analytics = {
      totalUrls: 10, // Example data
      totalClicks: 1000,
      uniqueUsers: 300,
      clicksByDate: [],
      osType: [],
      deviceType: []
    };
    res.json(analytics);
  });

  const redis = require('redis');
const client = redis.createClient();

client.on('error', (err) => {
  console.error('Redis error:', err);
});

// Cache middleware
const cache = (req, res, next) => {
  const { alias } = req.params;
  client.get(alias, (err, data) => {
    if (err) throw err;
    if (data !== null) {
      res.send(JSON.parse(data));
    } else {
      next();
    }
  });
};

app.get('/api/shorten/:alias', cache, async (req, res) => {
  const url = await Url.findOne({ shortUrl: req.params.alias });
  if (url) {
    client.setex(req.params.alias, 3600, JSON.stringify(url));
    res.redirect(url.longUrl);
  } else {
    res.status(404).send('URL not found');
  }
});
